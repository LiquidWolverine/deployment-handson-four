Code repository for [https://www.packtpub.com/books/content/simple-todo-list-web-application-nodejs-express-and-riot](https://www.packtpub.com/books/content/simple-todo-list-web-application-nodejs-express-and-riot)

Presently used by the following courses:
  - Deployment (FSWO108-3)
